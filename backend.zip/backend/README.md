## 环境配置

```bash
conda install -c conda-forge cmake
conda install -c conda-forge dlib
pip install face_recognition
```

添加员工

```
python add_employees.py --dir images/employees
```

