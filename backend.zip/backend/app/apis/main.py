from flask import (
    Blueprint
)
from utils import restful

main_bp = Blueprint(
    "main", __name__, url_prefix="/"
)






